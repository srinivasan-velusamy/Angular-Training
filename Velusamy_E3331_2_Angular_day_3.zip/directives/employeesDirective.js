app.directive('employeeDirective', function(){
	return {
		restrict: 'AE',
		templateUrl: 'directives/employeesDirective.html'
	};
});