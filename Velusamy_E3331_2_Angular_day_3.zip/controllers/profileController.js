//Scope implementation
angular.module('profile').controller('ProfileController', function($scope, employeeFactory){
	$scope.currentEmployee = employeeFactory.sharedProfile;
});