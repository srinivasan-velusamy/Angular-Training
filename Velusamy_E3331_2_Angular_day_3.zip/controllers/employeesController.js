angular.module('DemoApp').factory('employeeFactory', function(){
	return {
		sharedProfile: {
			name:'a',
			role:'b',
			project: {
				name : 'x',
				location : 'z'
			}
		},
		updateSharedProfile : function(newEmployee) {
			this.sharedProfile.name = newEmployee.name;
			this.sharedProfile.role = newEmployee.role;
			this.sharedProfile.project.name = newEmployee.project.name;
			this.sharedProfile.project.location = newEmployee.project.location;
		}
	};
	
});

//Scope implementation
app.controller('EmployeeController', function($scope, employeeFactory){
	
	$scope.employees =[ {"name":'John', "role":'SE', "project":{'name':'ABC', 'location': 'Chennai'}}, 
						{"name":'Bill', "role":'SSE', "project":{name:'XYZ', location: 'Bangalore'}}, 
						{"name":'Smith', "role":'QA', "project":{name:'MNO', location: 'US'}}, 
						{"name":'Donald', "role":'PM', "project":{name:'PQR', location: 'UK'}}];
	
	//Add User
	$scope.addUser = function(){
			
		$scope.employees.push({"name":$scope.name, "role": $scope.role, "project":{"name": $scope.project.name, "location":$scope.project.location}});
		$scope.name = null;
		$scope.role = null;
		$scope.project.name = null;
		$scope.project.location = null;	
		
	}
	
	//Delete User
	$scope.removeUser = function( idx ) {
		$scope.employees.splice(idx, 1);
	}
	
	//Show User
	$scope.showUser = function(currentEmployee){
		employeeFactory.updateSharedProfile(currentEmployee);
	}
	
	$scope.init = function() {
		$scope.showUser($scope.employees[0]);
	} 

	$scope.init();
});