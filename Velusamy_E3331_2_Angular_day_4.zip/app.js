angular.module('profile', []);
var app = angular.module('DemoApp', ['profile']);
			




			